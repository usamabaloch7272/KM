My Job KM Full v2 — GPS trip tracking, daily KM, monthly history, petrol rate and monthly report.
This is Android source code. It must be compiled into an APK using an Android build environment; it is not itself an APK.
