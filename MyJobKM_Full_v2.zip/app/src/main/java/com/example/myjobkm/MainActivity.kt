package com.example.myjobkm

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity: AppCompatActivity() {
 private lateinit var fused:FusedLocationProviderClient
 private lateinit var status:TextView
 private lateinit var kmText:TextView
 private lateinit var monthText:TextView
 private lateinit var rate:EditText
 private var running=false; private var todayKm=0.0; private var last:android.location.Location?=null
 private val prefs by lazy{getSharedPreferences("jobkm",0)}
 private val cb=object:LocationCallback(){override fun onLocationResult(r:LocationResult){
   val x=r.lastLocation?:return
   last?.let{todayKm+=it.distanceTo(x)/1000.0}
   last=x; save(); render()
 }}
 override fun onCreate(b:Bundle?){super.onCreate(b); fused=LocationServices.getFusedLocationProviderClient(this)
   val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL; l.setPadding(32,40,32,20)
   fun tv(s:String,z:Float)=TextView(this).apply{text=s;textSize=z}
   l.addView(tv("My Job KM",30f)); status=tv("Trip بند ہے",18f); kmText=tv("",22f); monthText=tv("",22f)
   rate=EditText(this); rate.hint="Petrol rate per KM (مثلاً 15)"; rate.inputType=2
   val start=Button(this);start.text="🟢 START TRIP"
   val stop=Button(this);stop.text="🔴 STOP TRIP"
   val report=Button(this);report.text="📊 MONTHLY REPORT"
   val reset=Button(this);reset.text="Reset Today"
   l.addView(status);l.addView(kmText);l.addView(monthText);l.addView(rate);l.addView(start);l.addView(stop);l.addView(report);l.addView(reset);setContentView(l);render()
   start.setOnClickListener{startTrip()};stop.setOnClickListener{stopTrip()}
   reset.setOnClickListener{todayKm=0.0;last=null;save();render()}
   report.setOnClickListener{showReport()}
 }
 private fun startTrip(){
   if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){
     ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),9);return}
   running=true;last=null;status.text="Trip چل رہی ہے..."
   fused.requestLocationUpdates(LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY,10000).setMinUpdateDistanceMeters(20f).build(),cb,mainLooper)
 }
 private fun stopTrip(){running=false;fused.removeLocationUpdates(cb);last=null;status.text="Trip بند ہے";render()}
 private fun date()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
 private fun save(){prefs.edit().putFloat("km_${date()}",todayKm.toFloat()).apply()}
 private fun render(){
   kmText.text="آج: %.2f KM".format(todayKm)
   val r=rate.text.toString().toDoubleOrNull()?:0.0
   monthText.text="Petrol: Rs %.0f".format(todayKm*r)
 }
 private fun showReport(){
   val now=Calendar.getInstance(); val sb=StringBuilder("MY JOB KM REPORT\n")
   var total=0.0
   for(d in 1..now.get(Calendar.DAY_OF_MONTH)){
     val c=now.clone() as Calendar;c.set(Calendar.DAY_OF_MONTH,d)
     val ds=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(c.time)
     val k=prefs.getFloat("km_$ds",0f).toDouble(); total+=k
     if(k>0)sb.append("$ds   %.2f KM\n".format(k))
   }
   val r=rate.text.toString().toDoubleOrNull()?:0.0
   sb.append("\nTOTAL: %.2f KM\nPETROL: Rs %.0f".format(total,total*r))
   AlertDialog.Builder(this).setTitle("Monthly Report").setMessage(sb.toString()).setPositiveButton("OK",null).show()
 }
}